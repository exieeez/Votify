---
name: Obsidian Wave
colors:
  surface: '#131314'
  surface-dim: '#131314'
  surface-bright: '#3a393a'
  surface-container-lowest: '#0e0e0f'
  surface-container-low: '#1c1b1c'
  surface-container: '#201f20'
  surface-container-high: '#2a2a2b'
  surface-container-highest: '#353436'
  on-surface: '#e5e2e3'
  on-surface-variant: '#c4c7c8'
  inverse-surface: '#e5e2e3'
  inverse-on-surface: '#313031'
  outline: '#8e9192'
  outline-variant: '#444748'
  surface-tint: '#c6c6c7'
  primary: '#ffffff'
  on-primary: '#2f3131'
  primary-container: '#e2e2e2'
  on-primary-container: '#636565'
  inverse-primary: '#5d5f5f'
  secondary: '#c8c6c9'
  on-secondary: '#303033'
  secondary-container: '#47464a'
  on-secondary-container: '#b6b4b8'
  tertiary: '#ffffff'
  on-tertiary: '#00363a'
  tertiary-container: '#7df4ff'
  on-tertiary-container: '#006f77'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e2e2e2'
  primary-fixed-dim: '#c6c6c7'
  on-primary-fixed: '#1a1c1c'
  on-primary-fixed-variant: '#454747'
  secondary-fixed: '#e4e1e5'
  secondary-fixed-dim: '#c8c6c9'
  on-secondary-fixed: '#1b1b1e'
  on-secondary-fixed-variant: '#47464a'
  tertiary-fixed: '#7df4ff'
  tertiary-fixed-dim: '#00dbe9'
  on-tertiary-fixed: '#002022'
  on-tertiary-fixed-variant: '#004f54'
  background: '#131314'
  on-background: '#e5e2e3'
  surface-variant: '#353436'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 40px
    fontWeight: '800'
    lineHeight: 48px
    letterSpacing: -0.03em
  headline-lg:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.025em
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.02em
  headline-sm:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
    letterSpacing: -0.015em
  body-lg:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: -0.01em
  body-md:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: -0.005em
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0em
  label-md:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
  label-mono:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.02em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  space-2xs: 0.125rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
  space-2xl: 2rem
  space-3xl: 3rem
  rail-width: 3.5rem
  player-height: 4.5rem
  gutter-desktop: 1.25rem
---

## Brand & Style
This design system defines an ultra-refined, pitch-black desktop audio streaming environment. Designed for audiophiles, producers, and discerning listeners who demand a high-density, distraction-free environment, the visual aesthetic leans on deep obsidian surfaces, monochromatic hierarchy, and razor-sharp typographic discipline. 

The emotional tone is immersive, silent, and architecturally precise—the interface dissolves entirely into the background, elevating vibrant album art, spectral waveforms, and essential playback controls. Visual movements balance extreme modern minimalism with high-precision translucent glass controls (frosted dark surfaces, whisper-thin rim lighting, and luminous white state indicators). Every interaction feels tactile yet weightless, offering immediate tactile feedback through micro-contrast states rather than garish color splashes.

## Colors
The palette is built on deep black obsidian tonal tiers designed for OLED and high-contrast desktop displays:
- **Canvas Base (`#0B0B0C`)**: The void background layer, grounding the primary viewport and side utility docks.
- **Surface Tier 1 (`#121214`)**: Used for persistent structural containers, floating player docks, and active content regions.
- **Surface Tier 2 (`#18181B`)**: Card backgrounds, popovers, context menus, and elevated controls.
- **Border / Hairline Subtle (`#27272A`)**: Minimal structural boundaries and inactive track rails.
- **Primary Text & High Accent (`#FFFFFF`)**: Pure active contrast for primary track metadata, active icons, and scrubber playheads.
- **Secondary Muted Text (`#A1A1AA` to `#71717A`)**: For artist credits, passive timestamps, and navigation labels.
- **Electric Cyan (`#00F0FF`)**: A hyper-sparing neon status accent for high-fidelity bitrate badges, active audio stream indicators, and lossless output locks.

## Typography
Typography is strictly neutral, geometric, and engineered for dense desktop information hierarchy. `Inter` handles all primary navigation, track titles, artist rosters, and headers with tight negative tracking on larger scales to produce a calibrated, modern editorial feel. 

For timestamps, durations, buffer metrics, and bitrate indicators, `JetBrains Mono` provides tabular monospaced alignment that eliminates horizontal layout shifting during playback. Text hierarchy relies decisively on weight transitions (Regular 400 to Bold 700) and optical opacity steps (100% white for active content, 65% for secondary artist names, 40% for subtle timestamps) rather than divergent type styles.

## Layout & Spacing
The layout follows a high-density, multi-pane desktop client philosophy:
- **Left/Right Utility Rails (`rail-width: 56px`)**: Ultra-compact, icon-only navigation bars pinned flush to the window frame.
- **Main Viewport Fluid Grid**: A flexible multi-column workspace scaling from 4 to 8 columns depending on desktop window width, accommodating media card carousels, algorithmic mix banners, and playlist tabular rows.
- **Fixed Persistent Player Bar (`player-height: 72px`)**: Grounded along the bottom (or floating detached with a 12px margin), providing continuous access to scrubbers, transport controls, and volume attenuation.
- **Density Scaling**: Tight 8px and 12px micro-paddings allow high song count visibility per vertical screen pass without aesthetic clutter.

## Elevation & Depth
Depth in this system is achieved through tonal stratification and ultra-fine glassmorphic refraction rather than standard drop shadows:
- **Base Level (Canvas)**: Solid `#0B0B0C`, absorptive and non-reflective.
- **Layer 1 (Containers & Docks)**: Semi-translucent `#121214` with a 24px backdrop blur (`backdrop-filter: blur(24px)`), paired with a razor-thin top highlight (`border-top: 1px solid rgba(255, 255, 255, 0.08)`).
- **Layer 2 (Overlays, Floating Controls, Context Menus)**: `#18181B` at 92% opacity, complemented by a subtle outer ring (`box-shadow: 0 0 0 1px rgba(255, 255, 255, 0.06), 0 12px 32px -8px rgba(0, 0, 0, 0.8)`).
- **Interactive Light Sheen**: Hovered artwork cards and segmented chips activate a top-to-bottom directional gradient shimmer from `rgba(255, 255, 255, 0.04)` to `rgba(255, 255, 255, 0.0)`.

## Shapes
A disciplined "Soft" curvature philosophy governs the interface. Standard album cards, buttons, track item hover bounds, and utility containers maintain a compact `0.25rem` (4px) to `0.5rem` (8px) corner radius, preserving a precision tool demeanor. 

Exceptions are reserved strictly for circular media transport icons (play/pause circles), pill toggles (`rounded-full`), and avatar badges, ensuring that functional audio controls visually contrast with content structural framing.

## Components

### Buttons & Transport Controls
- **Primary Play Action**: Solid pure white (`#FFFFFF`) pill or circle with an obsidian glyph (`#0B0B0C`). Micro-scale animation down to 0.96 scale on click.
- **Secondary Actions**: Transparent fill with `1px solid #27272A` border, elevating to `#FFFFFF` border with soft white icon fill on hover.
- **Transport Bar**: Minimalist icon controls (Next, Previous, Shuffle, Repeat) with inactive state at 40% white opacity, transitioning to 100% white with an active glowing cyan dot indicator below active states (e.g., Repeat Enabled).

### Track Scrubber & Volume Sliders
- Built on a 3px obsidian track (`#27272A`).
- Active progress bar is crisp `#FFFFFF` with hover expansion to 5px thickness.
- Draggable thumb is a crisp 10px circular white bead that remains hidden until track hover.

### Playlist & Track Rows
- Ultra-dense 44px vertical height with flexible column metadata: Track # / Playing visualizer EQ icon, Title + Artist, Album, Date Added, and Duration.
- Row background is transparent; hover activates a seamless `#121214` rounded pill bounding box.
- Playing track highlighted with bold title text and a miniature 3-bar animated cyan graphic equalizer indicator.

### Input Fields & Search Bars
- Background set to deep obsidian `#121214` with a hairline `#27272A` border.
- Floating search inputs incorporate an embedded keyboard shortcut chip (`Ctrl + K` / `⌘K`) rendered in muted monospace text.

### Segmented Tabs & Filter Chips
- Contained within an integrated `#121214` pill track.
- Active pill item transitions to elevated `#27272A` with solid `#FFFFFF` typography.