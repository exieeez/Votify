---
name: Nocturne Acoustic
colors:
  surface: '#121317'
  surface-dim: '#121317'
  surface-bright: '#38393d'
  surface-container-lowest: '#0d0e12'
  surface-container-low: '#1a1b1f'
  surface-container: '#1e1f23'
  surface-container-high: '#292a2e'
  surface-container-highest: '#343539'
  on-surface: '#e3e2e7'
  on-surface-variant: '#c4c7c8'
  inverse-surface: '#e3e2e7'
  inverse-on-surface: '#2f3034'
  outline: '#8e9192'
  outline-variant: '#444748'
  surface-tint: '#c6c6c7'
  primary: '#ffffff'
  on-primary: '#2f3131'
  primary-container: '#e2e2e2'
  on-primary-container: '#636565'
  inverse-primary: '#5d5f5f'
  secondary: '#53e076'
  on-secondary: '#003914'
  secondary-container: '#02b04c'
  on-secondary-container: '#003a14'
  tertiary: '#ffffff'
  on-tertiary: '#2f3131'
  tertiary-container: '#e2e2e2'
  on-tertiary-container: '#636565'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e2e2e2'
  primary-fixed-dim: '#c6c6c7'
  on-primary-fixed: '#1a1c1c'
  on-primary-fixed-variant: '#454747'
  secondary-fixed: '#72fe8f'
  secondary-fixed-dim: '#53e076'
  on-secondary-fixed: '#002108'
  on-secondary-fixed-variant: '#005320'
  tertiary-fixed: '#e2e2e2'
  tertiary-fixed-dim: '#c6c6c7'
  on-tertiary-fixed: '#1a1c1c'
  on-tertiary-fixed-variant: '#454747'
  background: '#121317'
  on-background: '#e3e2e7'
  surface-variant: '#343539'
typography:
  display-hero:
    fontFamily: Inter
    fontSize: 56px
    fontWeight: '800'
    lineHeight: 64px
    letterSpacing: -0.03em
  headline-lg:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.025em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 30px
    letterSpacing: -0.02em
  headline-sm:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.015em
  title-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-desktop: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
---

## Brand & Style
The design system embodies deep acoustic minimalism: an immersive, cinematic, night-first audio interface where content (album artwork, artist photography, and lyricism) commands primary focus. The UI retreats into pitch-dark negative space, allowing musical metadata and tactile controls to sit unobtrusively atop pure darkness.

Key aesthetic drivers:
- **Night-native immersion:** True charcoal-to-black canvas tones reduce visual fatigue and maximize contrast against vibrant album art.
- **Precision functionalism:** Controls and buttons utilize tactile rounded-pill shapes and low-contrast surface stepping rather than aggressive borders or heavy drop shadows.
- **Editorial restraint:** Modern typography pairs clean architectural layout logic with precise typographic hierarchies reminiscent of luxury audio players and contemporary streaming services.

## Colors
The palette leverages high-contrast extremes against deeply recessed dark grounds. 

- **Primary Canvas & Backgrounds:** The base layer lives at `#0f0f0f` for edge-to-edge canvas foundations, stepping gently into `#121212` for primary content panels, side navigation rails, and bottom sheets.
- **Elevated Surfaces:** Interactive containers, search fields, track rows on hover, and card elements rely on `#181818` (subtle resting container) and `#242424` (elevated control, card base, and input fill).
- **Text & Icon Tiers:**
  - *Primary (`#ffffff`):* Track titles, primary headings, playback active state, and high-emphasis labels.
  - *Secondary (`#a1a1aa`):* Artist names, metadata sublines, duration counters, inactive navigation items, and secondary iconography.
  - *Tertiary / Disabled (`#52525b`):* Progress track backdrops, divider guides, and disabled icons.
- **Accent & Highlight (`#1db954` / `#ffffff`):* Electric streaming green is reserved for active play states, current playback indicators, and shuffle/repeat states. Pure white functions as the primary action background (e.g., prominent "Play" pill buttons) with deep black iconography.

## Typography
Inter provides high-performance legibility across all screen densities. The typographic scale utilizes tight negative tracking on display and headline tiers to maintain cohesive tension across heavy bold titles, while body and label tiers maintain open tracking for instantaneous scanning in low-light environments. Numerical figures throughout the application (timestamps, stream counters, track rankings) utilize tabular figure styling (`font-feature-settings: 'tnum' on, 'cv05' on`) to ensure zero-jitter layout stability during playback scrub.

## Layout & Spacing
The layout follows an 8pt architectural rhythm, utilizing fluid, responsive grids:
- **Mobile (under 768px):** Single-column stacked layout with 16px margins, fluid horizontal scrolling carousels for albums and playlists, and a persistent 64px tall floating bottom mini-player above navigation.
- **Tablet (768px - 1024px):** 6-column fluid grid, 24px margins, a persistent 72px left-hand icon rail, and a pinned persistent bottom playback bar.
- **Desktop (1024px+):** 12-column asymmetric fluid grid, 32px canvas margins. Left navigation fixed at 280px width, dynamic main browse feed taking flexible remaining space, optional right context rail (now playing / queue / lyrics) fixed at 320px, and bottom playback bar spanning the entire viewport width at 88px height.

## Elevation & Depth
Depth in this design system is achieved strictly through tonal stacking and optical surface translucency, avoiding heavy, muddy dropshadows:
- **Base Canvas (`#0f0f0f`):** Root viewport backdrop.
- **Level 1 Panels (`#121212`):** Primary section containers and collection sheets.
- **Level 2 Containers (`#181818` to `#242424`):** Media cards, search inputs, modal bodies, and hovering track rows.
- **Floating Overlays & App Bars:** Utilizes frosted acrylic glassmorphism (`backdrop-filter: blur(24px) saturate(180%)`) paired with a semi-transparent base (`rgba(18, 18, 18, 0.75)`) and a hairline top border (`rgba(255, 255, 255, 0.08)`).
- **Persistent Floating Controls:** Floating action buttons and the mobile mini-player incorporate a subtle ambient aura (`box-shadow: 0 12px 32px -4px rgba(0, 0, 0, 0.7)`).

## Shapes
The system pairs organic pill architecture with modern soft geometry:
- **Full Pills (`rounded-full` / `9999px`):** Used strictly for interactive triggers, primary play/pause buttons, filter chips, search input containers, scrubber thumbs, and avatar masks.
- **Curved Rectangles (`rounded-2xl` / `1rem` to `1.5rem`):** Applied to album artwork covers, playlist hero cards, context menus, and modal dialogs.
- **Micro-radii (`rounded-md` / `0.375rem`):** Reserved for small contextual badges (e.g., explicit content flags, lossless/Dolby tags) and tooltips.

## Components

### Buttons
- **Primary Pill:** Background `#ffffff`, text `#000000`, bold typography, height 48px (or 40px compact), `rounded-full`, horizontal padding 24px. On hover: slight scale (`scale(1.04)`) with full opacity.
- **Secondary Pill:** Background `rgba(255, 255, 255, 0.08)`, text `#ffffff`, border `1px solid rgba(255, 255, 255, 0.12)`, `rounded-full`. On hover: background becomes `rgba(255, 255, 255, 0.16)`.
- **Icon Buttons (Play, Shuffle, Favorite):** 40x40px or 48x48px circular touch targets, transparent background, text `#a1a1aa`. Active/highlighted state shifts to `#1db954` or `#ffffff`.

### Chips & Filter Pills
- **Filter Chip:** Full pill (`rounded-full`), height 32px, padding 0 16px.
- **Resting:** Background `#242424`, text `#ffffff`, font-size 13px.
- **Selected:** Background `#ffffff`, text `#000000`, font-weight 600.

### Input Fields (Search & Filtering)
- **Container:** Height 44px, background `#242424`, border `1px solid transparent`, corner radius `rounded-full`.
- **Content:** Search magnifying glass prefix icon tinted `#8e8e93`, placeholder text `#8e8e93`, active text `#ffffff`.
- **Focus State:** Background `#2a2a2a`, border `1px solid rgba(255, 255, 255, 0.24)`, outline none.

### Track List Rows
- **Layout:** Height 56px, horizontal padding 12px, border-radius `0.5rem`, displaying index/play icon, artwork thumbnail (40x40px, `rounded-md`), track title (`#ffffff`), artist line (`#a1a1aa`), album name, track duration, and context overflow trigger.
- **Hover State:** Background `rgba(255, 255, 255, 0.06)`. Index shifts instantly to a pure white play icon.
- **Active / Playing State:** Title and index animate into `#1db954`.

### Media Cards
- **Structure:** Background `#181818`, transition `background 0.2s ease`, padding 16px, border-radius `rounded-2xl`. Hover state elevates surface to `#242424`.
- **Artwork Frame:** Square aspect ratio 1:1, border-radius `0.75rem`, subtle interior rim highlight.
- **Floating Action Play Button:** 48px circle positioned in the bottom-right corner of the artwork, background `#1db954` or `#ffffff` with black icon, transforms from `translate-y-2 opacity-0` to `translate-y-0 opacity-100` upon card hover.

### Sliders (Scrubber & Volume)
- **Track Rail:** Height 4px, background `#3f3f46`, `rounded-full`.
- **Progress Fill:** Height 4px, background `#ffffff` (or `#1db954` during playback), `rounded-full`.
- **Thumb:** 12px circle, background `#ffffff`, hidden during passive state, scales into visibility (`scale-100`) on track bar hover or drag.

### Checkboxes & Toggle Switches
- **Checkbox:** 18x18px square with `rounded-md` (4px), border `1.5px solid #52525b`. Checked: background `#1db954`, border-color `#1db954`, checkmark pure black `#000000`.
- **Switch:** Width 44px, height 24px, pill track (`rounded-full`), background `#3f3f46`. Active: background `#1db954`, white circular handle transitions across with spring curve.